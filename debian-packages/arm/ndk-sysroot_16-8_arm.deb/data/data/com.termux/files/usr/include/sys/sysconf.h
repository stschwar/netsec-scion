/*
 * This file used to contain the declarations of sysconf and its associated constants.
 * No standard mentions a <sys/sysconf.h>, but there are enough users in vendor (and potential ones
 * in the NDK) to warrant not breaking source compatibility.
 */
#include <bits/sysconf.h>
