/* This is a BSD synonym for <utmp.h> that's also provided by glibc. */
#include <utmp.h>
